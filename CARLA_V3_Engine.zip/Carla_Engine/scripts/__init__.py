"""Utility scripts for CARL marker tooling."""
