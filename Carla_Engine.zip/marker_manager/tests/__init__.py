"""Test suite for marker manager package."""
