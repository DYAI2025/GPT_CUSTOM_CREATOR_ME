# Blindspot Protocol
Vergleiche Profile (`brief` vs `clinical`), sammle Δ>0.25 bei Familien, ergänze ATO/SEM oder Gewichte, re-run, prüfe Change-Points.