# Tutorial
1. Profil wählen (`resources/profiles/*.yaml`).
2. Schema wählen (`resources/schemata/SCH_*.yaml`).
3. Text laden, `orchestrator.py --profile default --schema SCH_TEXT --file demo.txt`.
4. Ausgabe kopieren, in `resources/html/analyse.HTML` einfügen oder via `render_html()` injizieren.